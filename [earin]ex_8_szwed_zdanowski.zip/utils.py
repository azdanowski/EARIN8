def fix_rendering_on_windows():
    import colorama
    colorama.init()
    